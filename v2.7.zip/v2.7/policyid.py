def policyidvalue(arg):
  policyid = arg
  mylist = policyid.split("/")
  return mylist[0]
